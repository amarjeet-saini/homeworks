#include <no_strings_attached/string_trim.hpp>

namespace no_strings_attached {
    std::string Trim(const std::string& str, char char_to_trim, Side side) {
        std::string r{};
        // front 
        std::size_t front_pos = str.find(char_to_trim);
        // back
        std::size_t back_pos = str.find(char_to_trim);
        
        if(side == Side::kLeft) {
            if (front_pos != std::string::npos) r = str.substr(front_pos+1);
        }
        else if (side == Side::kRight) {
            if (back_pos != std::string::npos) r = str.substr(0,str.size() - back_pos);
        }
        else if (side == Side::kBoth) {           
            if (front_pos != std::string::npos && back_pos != std::string::npos) 
                r = str.substr(front_pos+1, str.size() - back_pos);
        }
        return r;
    }

    std::string Trim(const std::string& str) {
        return Trim(str,' ',Side::kBoth);
    }

} // namespace no_strings_attached

