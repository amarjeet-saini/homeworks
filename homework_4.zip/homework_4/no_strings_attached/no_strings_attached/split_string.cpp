#include <no_strings_attached/split_string.hpp>

namespace no_strings_attached {
    std::vector<std::string> Split(const std::string& str, const std::string& delimiter) {
        std::size_t pos;
        std::vector<std::string> svec{};
        do { 
            pos = str.find(delimiter);
            svec.push_back(str.substr(0,pos));
            str.substr(pos+delimiter.length());
        } while (pos != std::string::npos); 
        return svec;
    }

    std::vector<std::string> Split(const std::string& str, const std::string& delimiter, int number_of_chunks_to_keep) {
        std::vector<std::string> svec{};
        svec = Split(str, delimiter);
        if(svec.size()>=10){
            svec.resize(svec.size() - number_of_chunks_to_keep);
        }
        return svec;
    }

} // namespace no_strings_attached


